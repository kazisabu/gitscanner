import os
import json
from utils import load_keywords, load_extensions, scan_repo
from telegram_notify import send_telegram  # This must exist

REPO_LIST_FILE = "repos.txt"
KEYWORDS_FILE = "keywords.txt"
EXTENSIONS_FILE = "extensions.txt"
OUTPUT_FILE = "output/scan_report.json"

# 🔒 Hardcoded Telegram credentials
TELEGRAM_BOT_TOKEN = "Telegram_bot token"
TELEGRAM_CHAT_IDS = [
    "First chat ID",  
    "Second chat ID" #you can add multiple chat ids in here
]

def main():
    with open(REPO_LIST_FILE) as f:
        repos = [line.strip() for line in f if line.strip()]

    keywords = load_keywords(KEYWORDS_FILE)
    extensions = load_extensions(EXTENSIONS_FILE)

    all_results = []
    for repo_url in repos:
        print(f"[+] Scanning {repo_url}")
        results = scan_repo(repo_url, keywords, extensions)
        all_results.extend(results)

    os.makedirs("output", exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump(all_results, f, indent=2)

    print(f"[+] Scan complete. Results saved to {OUTPUT_FILE}")

    # 🔔 Send report to all Telegram chat IDs
    for chat_id in TELEGRAM_CHAT_IDS:
        try:
            send_telegram(TELEGRAM_BOT_TOKEN, chat_id, "🔍 Scan Completed. Here's your report:", OUTPUT_FILE)
        except Exception as e:
            print(f"[!] Failed to send report to chat ID {chat_id}: {e}")

if __name__ == "__main__":
    main()
