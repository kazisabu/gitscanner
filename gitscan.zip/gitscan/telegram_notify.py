import requests

def send_telegram(token, chat_id, message, file_path=None):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    if file_path:
        # Send file
        with open(file_path, "rb") as file_data:
            file_url = f"https://api.telegram.org/bot{token}/sendDocument"
            resp = requests.post(file_url, data={"chat_id": chat_id, "caption": message}, files={"document": file_data})
    else:
        # Send plain message
        resp = requests.post(url, data={"chat_id": chat_id, "text": message})
    
    print(f"[+] Telegram response: {resp.status_code} - {resp.text}")
    return resp.status_code == 200
