import requests
import re
from tqdm import tqdm

# Add your GitHub token
GITHUB_TOKEN = "Your_githubs_Token" 

def load_keywords(path):
    with open(path) as f:
        return [line.strip() for line in f if line.strip()]

def load_extensions(path):
    with open(path) as f:
        return [line.strip() for line in f if line.strip()]

def get_repo_content(owner, repo, path=""):
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"} if GITHUB_TOKEN else {}
    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        return []
    return resp.json()

def scan_repo(repo_url, keywords, extensions):
    owner, repo = repo_url.strip().split("/")[-2:]
    stack = [""]
    results = []
    
    while stack:
        current_path = stack.pop()
        contents = get_repo_content(owner, repo, current_path)
        for item in contents:
            if item["type"] == "dir":
                stack.append(item["path"])
            elif item["type"] == "file" and any(item["name"].endswith(ext) for ext in extensions):
                file_resp = requests.get(item["download_url"])
                if file_resp.status_code != 200:
                    continue
                lines = file_resp.text.splitlines()
                for i, line in enumerate(lines, 1):
                    for pattern in keywords:
                        if re.search(pattern, line):
                            results.append({
                                "repo": f"{owner}/{repo}",
                                "file": item["path"],
                                "line": i,
                                "match": line.strip()
                            })
    return results
